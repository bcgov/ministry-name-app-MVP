let ministry = {rows:[
    {
      ministry_id: '1',
      ministry_name: 'Agriculture and Food',
      acronym:'AF'
    },
    {
        ministry_id: '2',
        ministry_name: 'Attorney General',
        acronym:'AG'
    },
    {
        ministry_id: '3',
        ministry_name: 'Children and Family Development',
        acronym:'CFD'
    },
    {
        ministry_id: '4',
        ministry_name: 'Minister of State for Child Care',
        acronym:'CHILD'
    },
    {
        ministry_id: '5',
        ministry_name: 'Citizens Services',
        acronym:'CITZ'
    },
    {
        ministry_id: '6',
        ministry_name: 'Education and Child Care',
        acronym:'ECC'
    }
]};


  
  export default {
    ministry,
  };