console.log(`hit common.js file`);

//______________________Function Definitions_______________
